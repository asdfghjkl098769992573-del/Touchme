# Touch Me (Android)

Offline study timer. A WebView shell around `app/src/main/assets/index.html` with native extras:
permanent JEE countdown notification (foreground service) and Do Not Disturb ("alarms only") during focus.

## Get the APK without installing anything (GitHub Actions)

1. Create a new GitHub repository (private is fine).
2. Upload everything in this folder, keeping the folder structure (including the hidden `.github` folder).
3. Open the **Actions** tab -> **Build Touch Me APK** -> wait for the green tick (about 3-5 min).
   If it did not start by itself, press **Run workflow**.
4. Open the finished run -> **Artifacts** -> download `touch-me-apk` (a zip containing `app-debug.apk`).
5. On the phone: unzip, tap the APK, allow "Install unknown apps" when asked.

## Or build locally

Open the folder in Android Studio and press Run, or run `gradle assembleDebug` (Gradle 8.9+, JDK 17, Android SDK 34).

## First launch

- Settings -> turn on **Permanent notification countdown**.
- Settings -> turn on **Block notifications in focus**. Android opens a screen where you must allow "Touch Me" under *Do Not Disturb access* once.
- On Samsung phones, set Touch Me's battery usage to **Unrestricted** so the notification is never killed.

## Native bridge (window.Android in the web app)

session(bool) keep screen on + ignore Back | dnd(bool) | hasDnd() | openDndSettings() | lockLandscape(bool) | jeeNotif(on, targetMillis, unitMask 1=mo 2=wk 4=d 8=h)
