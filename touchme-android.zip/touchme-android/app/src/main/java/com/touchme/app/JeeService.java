package com.touchme.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.text.NumberFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/** Permanent, silent notification that shows the JEE Mains countdown. Updates once a minute to save battery. */
public class JeeService extends Service {

    private static final String CHANNEL = "touchme_jee";
    private static final int NOTIF_ID = 7;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Notification.Builder builder;
    private NotificationManager manager;
    private long target;
    private int mask;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            long now = System.currentTimeMillis();
            handler.postDelayed(this, 60000 - (now % 60000) + 200);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences("touchme_native", MODE_PRIVATE);
        target = p.getLong("jee_target", 0);
        mask = p.getInt("jee_mask", 15);

        manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL, "JEE countdown", NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            c.setSound(null, null);
            c.enableVibration(false);
            manager.createNotificationChannel(c);
        }

        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        builder = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("JEE Mains")
                .setContentText(text())
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setContentIntent(pi)
                .setCategory(Notification.CATEGORY_STATUS)
                .setVisibility(Notification.VISIBILITY_PUBLIC);

        // Must be called right after startForegroundService().
        startForeground(NOTIF_ID, builder.build());

        if (target <= 0) {
            stopSelf();
            return START_NOT_STICKY;
        }

        handler.removeCallbacks(tick);
        handler.post(tick);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        super.onDestroy();
    }

    private void update() {
        if (builder == null || manager == null) return;
        builder.setContentText(text());
        manager.notify(NOTIF_ID, builder.build());
    }

    private String text() {
        if (target <= 0) return "Counting down";
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime now = LocalDateTime.now(zone);
        LocalDateTime t = LocalDateTime.ofInstant(Instant.ofEpochMilli(target), zone);
        if (!t.isAfter(now)) return "It's time. Go.";

        long months = ChronoUnit.MONTHS.between(now, t);
        long ms = Duration.between(now, t).toMillis();
        NumberFormat nf = NumberFormat.getIntegerInstance(new Locale("en", "IN"));

        StringBuilder sb = new StringBuilder();
        if ((mask & 1) != 0) add(sb, nf.format(months) + " mo");
        if ((mask & 2) != 0) add(sb, nf.format(ms / 604800000L) + " wk");
        if ((mask & 4) != 0) add(sb, nf.format(ms / 86400000L) + " d");
        if ((mask & 8) != 0) add(sb, nf.format(ms / 3600000L) + " h");
        return sb.length() == 0 ? "Counting down" : sb.toString();
    }

    private static void add(StringBuilder sb, String part) {
        if (sb.length() > 0) sb.append("  ·  ");
        sb.append(part);
    }
}
