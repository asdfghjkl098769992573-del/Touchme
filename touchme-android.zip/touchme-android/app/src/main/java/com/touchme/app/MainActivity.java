package com.touchme.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView web;
    private SharedPreferences prefs;
    private boolean sessionActive = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("touchme_native", MODE_PRIVATE);
        restoreDndIfLeftOn();

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    /** While a study session is running, the back button is ignored so you can't leave by accident. */
    @Override
    public void onBackPressed() {
        if (sessionActive) return;
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        applyDnd(false);
        super.onDestroy();
    }

    // ---------- Do Not Disturb ----------

    private NotificationManager nm() {
        return (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    }

    /** If the app was killed during focus, put the phone's sound mode back on next launch. */
    private void restoreDndIfLeftOn() {
        int saved = prefs.getInt("dnd_saved", -1);
        if (saved == -1) return;
        try {
            NotificationManager n = nm();
            if (n.isNotificationPolicyAccessGranted()) n.setInterruptionFilter(saved);
        } catch (Exception ignored) {
        }
        prefs.edit().putInt("dnd_saved", -1).apply();
    }

    /** "Alarms only": blocks notifications and calls but keeps alarms and the app's own chime. */
    private void applyDnd(boolean on) {
        try {
            NotificationManager n = nm();
            if (!n.isNotificationPolicyAccessGranted()) return;
            int saved = prefs.getInt("dnd_saved", -1);
            if (on) {
                if (saved == -1) {
                    int cur = n.getCurrentInterruptionFilter();
                    if (cur < 1 || cur > 4) cur = NotificationManager.INTERRUPTION_FILTER_ALL;
                    prefs.edit().putInt("dnd_saved", cur).apply();
                }
                n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
            } else if (saved != -1) {
                n.setInterruptionFilter(saved);
                prefs.edit().putInt("dnd_saved", -1).apply();
            }
        } catch (Exception ignored) {
        }
    }

    // ---------- JavaScript bridge (window.Android in the web app) ----------

    private class Bridge {

        @JavascriptInterface
        public void session(final boolean on) {
            runOnUiThread(() -> {
                sessionActive = on;
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                hideBars();
            });
        }

        @JavascriptInterface
        public void dnd(final boolean on) {
            runOnUiThread(() -> applyDnd(on));
        }

        @JavascriptInterface
        public boolean hasDnd() {
            try {
                return nm().isNotificationPolicyAccessGranted();
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void openDndSettings() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void lockLandscape(final boolean on) {
            runOnUiThread(() -> setRequestedOrientation(on
                    ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
        }

        /** Starts or stops the permanent JEE countdown notification. */
        @JavascriptInterface
        public void jeeNotif(boolean on, double targetMillis, int unitMask) {
            Intent svc = new Intent(MainActivity.this, JeeService.class);
            if (on && targetMillis > 0) {
                prefs.edit()
                        .putBoolean("jee_on", true)
                        .putLong("jee_target", (long) targetMillis)
                        .putInt("jee_mask", unitMask)
                        .apply();
                try {
                    startForegroundService(svc);
                } catch (Exception ignored) {
                }
            } else {
                prefs.edit().putBoolean("jee_on", false).apply();
                stopService(svc);
            }
        }
    }
}
