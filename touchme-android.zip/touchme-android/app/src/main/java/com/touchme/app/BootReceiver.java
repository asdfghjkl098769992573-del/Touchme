package com.touchme.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Brings the permanent countdown notification back after the phone restarts. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        SharedPreferences p = context.getSharedPreferences("touchme_native", Context.MODE_PRIVATE);
        if (!p.getBoolean("jee_on", false)) return;
        try {
            context.startForegroundService(new Intent(context, JeeService.class));
        } catch (Exception ignored) {
        }
    }
}
